# 專案：AI 發文辦公室（初版）

## 目標
一個人＋AI 團隊，穩定產出高品質貼文，累積受眾，之後導向付費產品（中文工具、範本、教學）。
人類（我）負責最後核准；AI 負責研究、寫作、校稿。

## 基本設定【待填】
- 發文平台：Threads（【待填】若改 FB 粉專／部落格／電子報請修改）
- 主題方向：
  1. 工程人的 AI 實戰（用 AI 處理報告書、資料整理、自動化）
  2. 水利／防災軟體中文教學（HEC-RAS、SWMM、progeCAD 操作與常見錯誤）
- 目標讀者：工程顧問公司工程師、土木水利研究生、公部門承辦
- 語氣：【待填】例如「實務、直接、像資深同事分享，不浮誇」
- 篇幅：Threads 每篇 300–500 字，可拆串文（每段 ≤ 500 字）
- 禁止：誇大收益、保證式用語、未查證的數字、洩漏任何客戶／案件資訊、貶低他人

## 團隊（Claude Code 子代理）
主對話 = 主管（由 /dispatch 指令驅動），子代理在 `.claude/agents/`：
| 角色 | 檔案 | 產出位置 |
|---|---|---|
| 研究員 researcher | researcher.md | content/research/ |
| 寫手 writer | writer.md | content/drafts/ |
| 校稿員 proofreader | proofreader.md | content/review/ 或退回 |

## 檔案命名
`YYYYMMDD-短標題.md`，同一篇在各資料夾用同一個檔名。
每份稿件開頭放 YAML：
```
---
title:
topic:
platform:
status: research | draft | revise | review | approved | published
revisions: 0
sources: []
---
```

## 狀態紀錄
每個步驟完成時，在 `status/log.md` 追加一行：
`時間 | 角色 | 動作 | 檔名`
（第二階段的看板／3D 辦公室會讀這個檔，格式不要改）

## 初版範圍（只做這些）
- [ ] 3 個子代理 + /dispatch 指令跑通
- [ ] 試產 3 篇，我核准後依回饋調整子代理說明
- 不寫程式、不接平台 API、不做畫面

## 第二階段（初版穩定後才做）
1. 簡易狀態看板：本機網頁讀 status/log.md，顯示誰在忙、幾篇待核准
2. 接 Agent Office 3D（github.com/jefferysha0627/agent-office-3d）或改成原創小動物風格
3. 發文員：用平台官方 API 排程發出 content/approved/ 的稿件
4. 分析師：每週整理成效，回饋選題

## 工作原則
- 省 token：讀檔只讀需要的部分；不要重複產出整篇，只改需要改的段落
- 不確定的事實寧可刪掉，或標記【待查】交給我
- 任何會對外發布的動作都必須先經過我
