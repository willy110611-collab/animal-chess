@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "OFFICE_DIR=%~dp0"
set "PYW="
for /f "delims=" %%i in ('where pyw 2^>nul') do if not defined PYW set "PYW=%%i"
if not defined PYW for /f "delims=" %%i in ('where pythonw 2^>nul') do if not defined PYW set "PYW=%%i"
if not defined PYW (echo 找不到 Python，請先安裝 Python 3 & pause & exit /b 1)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$q=[char]34; $s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\ZooOffice.lnk'); $s.TargetPath=$env:PYW; $s.Arguments=$q+$env:OFFICE_DIR+'office\server.py'+$q+' --no-browser'; $s.WorkingDirectory=$env:OFFICE_DIR; $s.WindowStyle=7; $s.Save()"
start "" "%PYW%" "%~dp0office\server.py" --no-browser
echo.
echo 完成：開機會自動在背景開辦公室（不會跳出視窗）。
echo 桌布網址：http://127.0.0.1:8770/?wallpaper
echo 到 Lively Wallpaper 按「+」貼上這個網址，並在 Lively 設定裡打開「開機時啟動」。
pause
