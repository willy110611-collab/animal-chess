# AI 發文辦公室｜開工封包 v0.1

## 怎麼用（3 步）
1. 把整個資料夾放到電腦上，例如 `D:\ai-office`
2. 先花 10 分鐘填好下面兩個地方（不花 token）：
   - `CLAUDE.md` 裡標 **【待填】** 的部分（平台、題目、語氣）
   - `style/examples/` 放 5–10 篇你覺得寫得好的範例貼文（.md 或 .txt）
3. 在這個資料夾開 Claude Code，貼上：

```
請先讀 CLAUDE.md 和 .claude/ 底下所有檔案，確認你理解初版範圍。
不要寫任何程式，先用 /dispatch 跑一次試產：主題「用 AI 整理 HEC-RAS 輸出成報告表格」。
```

## 初版做到什麼
`/dispatch 主題` → 研究員 → 寫手 → 校稿員（不過關退回，最多 2 輪）→ 放進 `content/review/` 等你核准。
你看完把檔案移到 `content/approved/` 就算核准，**初版不自動發文**。

## 省額度原則
- 初版完全不寫程式，只用 Claude Code 內建的子代理 + 指令
- 每次派工只做 1 篇
- 跑順了再進第二階段（狀態看板、3D 辦公室、自動發文）

## 辦公室畫面（3D 小動物辦公室）
1. 雙擊 **open-office.bat**（手動開辦公室）（需要 Python；Mac 用 `python3 office/server.py`）→ 瀏覽器自動開 http://127.0.0.1:8770
2. 第一次開會自動把 hooks 寫進 `.claude/settings.json`。**已經開著的 Claude Code 要關掉重開**才會開始回報。
3. 之後在這個資料夾用 Claude Code 做事（或在辦公室畫面輸入主題按「派工」），動物會照實際進度動：
   - 主管＝主對話；研究／文案／校稿＝子代理；工具名稱（WebSearch、Read、Write…）會掛在名牌上
   - Claude 需要你按允許時，主管會顯示「等你回覆」
   - 沒事的會去坐沙發、睡覺、喝水、看書、打電動、兩人一組打桌球
4. 拖曳畫面可轉視角。關掉黑色視窗＝關掉辦公室（不影響 Claude Code）。

可調的地方：
- `office/office.html` 開頭 `ROLES`：人員、動物（動物戰棋 33 隻的英文代號）、顏色；`k` 要跟 `.claude/agents/` 的 name 一樣。沒列到的子代理會自動補一隻，最多 8 位。
- 同一處 `OFFICE_CFG`：角色大小、走路速度、休息多久換地方、睡覺機率。
- `office/server.py` 開頭：連接埠、按「派工」時允許的工具（預設不允許執行指令）。
- 紀錄檔：`status/events.jsonl`（hooks 寫的，超過 5MB 會自動縮小）、`status/dispatch.log`（按派工時 Claude 的輸出）。

## 當桌面桌布＋開機自動開
1. 雙擊 **1-START-autostart.bat（設定開機自動開）**：之後開機會在背景開辦公室（不跳視窗），現在也會先開起來。
2. 安裝 **Lively Wallpaper**（免費，Microsoft Store 搜尋 Lively）→ 按「+」→ 貼上 `http://127.0.0.1:8770/?wallpaper` → 設成桌布。
3. Lively 設定裡打開「開機時啟動」。
- 桌布版：全螢幕辦公室、鏡頭慢慢轉、右上角即時看板（燈號：綠＝運作中、黃＝等你、紅＝有退回、灰＝休息）。沒人工作 1 分鐘後看板變淡、畫面更新變慢省電。
- 不想開機自動開：雙擊 **stop-autostart.bat（取消開機自動開）**。

## 人員自動增加
在 `.claude/agents/` 新增子代理（例如 designer.md），辦公室會在 15 秒內自動多一隻動物、多一張桌子（職稱取 description 的第一句）。座位最多 10 張，超過的人會站著工作。想指定動物，改 `office/office.html` 開頭的 `ROLES`。

## 鏡頭轉動、特色辦公桌
- 鏡頭預設不轉。要轉：按畫面上的「鏡頭轉動：關／開」（桌布版在右上看板最下面；Lively 要開啟滑鼠輸入才按得到），或把桌布網址改成 `http://127.0.0.1:8770/?wallpaper&spin=1`。設定會記在這台電腦。
- 每隻動物有自己的辦公桌（獅子金邊桌＋獎盃、貓頭鷹書堆＋檯燈、鸚鵡棲木＋便利貼、刺蝟稿紙＋紅筆、企鵝冰桌＋雪堆、狐狸長條圖白板）；其他動物依羈絆配一組。改在 `office/office.html` 的 `DESK_THEME`。
- 桌布順暢度：`OFFICE_CFG.WP_FPS`（預設每秒 60 張；想省電改 30）。

## 所有專案都會出現在辦公室（全域回報）
- 辦公室啟動時，會把回報設定寫進這台電腦的全域設定 `C:\Users\你的帳號\.claude\settings.json`（原本的設定會保留，第一次修改前備份成 `settings.json.bak-office`）。
- 之後在**任何資料夾**用 Claude Code，主管獅子都會動；動態前面會標〔專案名稱〕，例如〔animal-chess〕。
- 已經開著的 Claude Code 要關掉重開才會開始回報。
- 不想要了：把 `settings.json.bak-office` 改回 `settings.json`，或刪掉 settings.json 裡含 `office/hook.py` 的那幾段。

## 錄影模式
網址後面加 `#show`（全員工作 2 分鐘）或 `#show30`（30 秒），例如 `http://127.0.0.1:8770/?wallpaper#show30`。
