@echo off
cd /d "%~dp0"
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\ZooOffice.lnk" 2>nul
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like *office*server.py* } | ForEach-Object { Stop-Process -Id $_.ProcessId }"
echo Autostart removed and the office has been stopped.
pause
