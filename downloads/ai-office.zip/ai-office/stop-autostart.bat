@echo off
chcp 65001 >nul
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\ZooOffice.lnk" 2>nul
echo Autostart removed. The office will not start with Windows anymore.
pause
