@echo off
cd /d "%~dp0"
py -3 office\server.py --install-autostart
if errorlevel 9009 python office\server.py --install-autostart
if errorlevel 9009 echo Python not found. Install it from https://www.python.org/downloads and tick "Add python.exe to PATH".
echo.
pause
