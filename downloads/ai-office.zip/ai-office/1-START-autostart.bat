@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "OFFICE_DIR=%~dp0"
set "PYW="
for /f "delims=" %%i in ('where pyw 2^>nul') do if not defined PYW set "PYW=%%i"
if not defined PYW for /f "delims=" %%i in ('where pythonw 2^>nul') do if not defined PYW set "PYW=%%i"
if not defined PYW (echo Python not found. Please install Python 3 first: https://www.python.org/downloads & pause & exit /b 1)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$q=[char]34; $s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\ZooOffice.lnk'); $s.TargetPath=$env:PYW; $s.Arguments=$q+$env:OFFICE_DIR+'office\server.py'+$q+' --no-browser'; $s.WorkingDirectory=$env:OFFICE_DIR; $s.WindowStyle=7; $s.Save()"
start "" "%PYW%" "%~dp0office\server.py" --no-browser
echo.
echo DONE. The office now starts automatically in the background when Windows starts.
echo Office page:    http^://127.0.0.1:8770
echo Wallpaper URL:  http^://127.0.0.1:8770/?wallpaper
echo Paste the wallpaper URL into Lively Wallpaper ^(+ button^).
pause
