@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -3 office\server.py
if errorlevel 9009 python office\server.py
pause
