@echo off
chcp 65001 >nul
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\ZooOffice.lnk" 2>nul
echo 已取消開機自動開辦公室（目前開著的，重開機後就不會再開）。
pause
