# Claude Code hook：把每個事件記成一行，寫進 status/events.jsonl，給辦公室畫面讀
# 由 .claude/settings.json 呼叫。只寫檔、不輸出任何文字（輸出會被當成給 Claude 的訊息），出錯也不影響 Claude 工作。
import sys, json, os, time

def short(v, n=120):
    v = '' if v is None else str(v)
    return v if len(v) <= n else v[:n] + '…'

def main():
    raw = sys.stdin.buffer.read().decode('utf-8', 'replace')
    d = json.loads(raw or '{}')
    root = os.environ.get('CLAUDE_PROJECT_DIR') or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    ti = d.get('tool_input') or {}
    target = ti.get('file_path') or ti.get('notebook_path') or ti.get('path') or ti.get('query') or ti.get('url') or ti.get('pattern') or ti.get('command') or ''
    if target and os.path.isabs(str(target)):
        try: target = os.path.relpath(str(target), root)
        except ValueError: pass
    ev = {
        't': int(time.time() * 1000),
        'e': d.get('hook_event_name', ''),
        'tool': d.get('tool_name', ''),
        'agent': d.get('agent_type', ''),          # 在子代理裡面時才有，例如 researcher
        'aid': d.get('agent_id', ''),
        'sub': ti.get('subagent_type', ''),         # 主管派工（Agent 工具）時，派給誰
        'desc': short(ti.get('description', ''), 80),
        'target': short(target),
        'prompt': short(d.get('prompt', ''), 120),
        'msg': short(d.get('message', ''), 120),
    }
    ev = {k: v for k, v in ev.items() if v not in ('', None)}
    os.makedirs(os.path.join(root, 'status'), exist_ok=True)
    with open(os.path.join(root, 'status', 'events.jsonl'), 'a', encoding='utf-8') as f:
        f.write(json.dumps(ev, ensure_ascii=False) + '\n')

try:
    main()
except Exception:
    pass
sys.exit(0)
