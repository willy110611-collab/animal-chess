# 小動物發文辦公室：本機伺服器（只用 Python 內建模組，不用裝任何東西）
# 用法：雙擊「開辦公室.bat」，或在 ai-office 資料夾執行  py -3 office/server.py
# 做的事：
#   1. 開 http://127.0.0.1:8770 顯示辦公室畫面（只有這台電腦連得到）
#   2. 把 status/events.jsonl（Claude Code hooks 寫的）即時傳給畫面
#   3. 畫面上按「派工」→ 在背景執行  claude -p "/dispatch 主題"
#   4. 第一次執行時，把 hooks 設定寫進 .claude/settings.json（用這台電腦的 Python 路徑）
import http.server, socketserver, json, os, sys, subprocess, shutil, webbrowser, threading, glob, re, time
from urllib.parse import urlparse, parse_qs

# ===== 可調設定 =====
PORT = int(os.environ.get('OFFICE_PORT', '8770'))
# 派工時預先允許的工具（沒列的工具會被拒絕，例如 Bash）
ALLOWED_TOOLS = 'Read,Write,Edit,Glob,Grep,WebSearch,WebFetch,Agent'
MAX_EVENTS_MB = 5          # events.jsonl 超過這個大小，啟動時只留最後 1MB

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
EV = os.path.join(ROOT, 'status', 'events.jsonl')
RUN_LOG = os.path.join(ROOT, 'status', 'dispatch.log')
HOOK_EVENTS = ['UserPromptSubmit', 'PreToolUse', 'PostToolUse', 'SubagentStart', 'SubagentStop', 'Notification', 'Stop']
NO_MATCHER = {'UserPromptSubmit', 'Stop'}
proc = None

def ensure_hooks():
    """把辦公室的 hook 加進 .claude/settings.json（保留原本其他設定）。"""
    p = os.path.join(ROOT, '.claude', 'settings.json')
    try:
        cfg = json.load(open(p, encoding='utf-8')) if os.path.exists(p) else {}
    except Exception:
        print('⚠ .claude/settings.json 讀不懂，沒有修改它；請檢查格式'); return
    py = sys.executable.replace('\\', '/')
    cmd = f'"{py}" "{os.path.join(HERE, "hook.py").replace(chr(92), "/")}"'
    hooks = cfg.setdefault('hooks', {})
    changed = False
    for ev in HOOK_EVENTS:
        lst = hooks.setdefault(ev, [])
        # 移除舊的辦公室 hook（路徑可能換過），再加回新的
        keep = [g for g in lst if not any('office/hook.py' in (h.get('command') or '').replace('\\', '/') for h in g.get('hooks', []))]
        entry = {'hooks': [{'type': 'command', 'command': cmd, 'timeout': 5}]}
        if ev not in NO_MATCHER: entry = {'matcher': '*', **entry}
        new = keep + [entry]
        if new != lst: hooks[ev] = new; changed = True
    if changed:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        json.dump(cfg, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
        print('✓ 已把辦公室 hooks 寫進 .claude/settings.json（已開著的 Claude Code 要重開才會生效）')

def trim_events():
    os.makedirs(os.path.dirname(EV), exist_ok=True)
    if not os.path.exists(EV): open(EV, 'w').close(); return
    if os.path.getsize(EV) > MAX_EVENTS_MB * 1024 * 1024:
        with open(EV, 'rb') as f:
            f.seek(-1024 * 1024, 2); data = f.read()
        data = data[data.find(b'\n') + 1:]
        open(EV, 'wb').write(data)

def review_count():
    return len(glob.glob(os.path.join(ROOT, 'content', 'review', '*.md')))

def read_events(since):
    size = os.path.getsize(EV) if os.path.exists(EV) else 0
    if since < 0: return size, []
    if since > size: since = 0                      # 檔案被清掉過
    with open(EV, 'rb') as f:
        f.seek(since); data = f.read()
    end = data.rfind(b'\n') + 1                     # 只讀完整的行
    out = []
    for line in data[:end].decode('utf-8', 'replace').splitlines():
        try: out.append(json.loads(line))
        except Exception: pass
    return since + end, out

def list_agents():
    """讀 .claude/agents/*.md 的 name 與 description（description 第一句當職稱）。"""
    out = []
    for f in sorted(glob.glob(os.path.join(ROOT, '.claude', 'agents', '*.md'))):
        try: head = open(f, encoding='utf-8').read(2000)
        except Exception: continue
        m = re.search(r'^---\s*\n(.*?)\n---', head, re.S)
        meta = dict(re.findall(r'^(\w+):\s*(.*)$', m.group(1), re.M)) if m else {}
        name = meta.get('name') or os.path.splitext(os.path.basename(f))[0]
        role = re.split(r'[。，,.]', meta.get('description', ''))[0].strip()[:6]
        out.append({'name': name, 'role': role or name})
    return out

def find_claude():
    for n in ('claude', 'claude.cmd', 'claude.exe'):
        p = shutil.which(n)
        if p: return p
    return None

def dispatch(topic):
    global proc
    if proc and proc.poll() is None: return 409, '上一篇還在跑'
    exe = find_claude()
    if not exe: return 500, '找不到 claude 指令'
    topic = re.sub(r'["%^&|<>!`\r\n]', ' ', topic).strip()[:200]   # 去掉命令列特殊字元
    if not topic: return 400, '主題是空的'
    log = open(RUN_LOG, 'a', encoding='utf-8')
    log.write(f'\n===== {time.strftime("%Y-%m-%d %H:%M:%S")} /dispatch {topic}\n'); log.flush()
    proc = subprocess.Popen([exe, '-p', '/dispatch ' + topic, '--allowedTools', ALLOWED_TOOLS],
                            cwd=ROOT, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
    return 200, 'ok'

class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def send(self, code, body, ctype='application/json; charset=utf-8'):
        b = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode('utf-8')
        self.send_response(code); self.send_header('Content-Type', ctype); self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        u = urlparse(self.path)
        if u.path in ('/', '/index.html'):
            return self.send(200, open(os.path.join(HERE, 'office.html'), 'rb').read(), 'text/html; charset=utf-8')
        if u.path == '/api/ping':
            return self.send(200, {'ok': True, 'project': os.path.basename(ROOT)})
        if u.path == '/api/agents':
            return self.send(200, {'agents': list_agents()})
        if u.path == '/api/events':
            try: since = int(parse_qs(u.query).get('since', ['-1'])[0])
            except ValueError: since = -1
            nxt, evs = read_events(since)
            return self.send(200, {'next': nxt, 'events': evs, 'review': review_count(), 'running': bool(proc and proc.poll() is None)})
        self.send(404, {'error': 'not found'})
    def do_POST(self):
        # 只接受本頁送來的請求（自訂標頭，其他網站的網頁送不出來）
        if urlparse(self.path).path != '/api/dispatch' or self.headers.get('X-Office') != '1':
            return self.send(403, {'error': 'forbidden'})
        try:
            n = min(int(self.headers.get('Content-Length', '0')), 4096)
            topic = str(json.loads(self.rfile.read(n) or b'{}').get('topic', ''))
        except Exception:
            return self.send(400, {'error': 'bad request'})
        code, msg = dispatch(topic)
        self.send(code, {'msg': msg})

class Srv(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True; allow_reuse_address = True

if __name__ == '__main__':
    trim_events(); ensure_hooks()
    url = f'http://127.0.0.1:{PORT}/'
    try:
        srv = Srv(('127.0.0.1', PORT), H)
    except OSError:
        print(f'連接埠 {PORT} 已被使用：辦公室可能已經開著了 → {url}')
        if '--no-browser' not in sys.argv: webbrowser.open(url)
        sys.exit(0)
    print(f'辦公室已開：{url}　（關掉這個視窗就會停止）\n桌布網址（給 Lively Wallpaper）：{url}?wallpaper')
    if '--no-browser' not in sys.argv: threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try: srv.serve_forever()
    except KeyboardInterrupt: pass
