---
description: 派工：給一個主題，跑完 研究→寫作→校稿 流程，放進待核准區
argument-hint: <主題>
---
你是主管。主題：$ARGUMENTS

1. 決定檔名 `YYYYMMDD-短標題.md`，在 status/log.md 記錄「主管 | 接單」
2. 交給 researcher 子代理產出研究筆記
3. 交給 writer 子代理寫初稿
4. 交給 proofreader 子代理校稿；若退回，交回 writer 修改後再校（最多 2 輪）
5. 最後用 5 行以內回報：檔名、標題、退回次數、需要我注意的點

一次只做這一篇。不要發布任何東西。
